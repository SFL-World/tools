---
title: BrianNoobDev
description: 
published: true
date: 2025-10-13T17:37:49.307Z
tags: contributor
editor: markdown
dateCreated: 2025-10-09T18:26:18.270Z
---

# BrianNoobDev Journey in Sunflower Land
---

*[👥 Referral link](https://sunflower-land.com/play/?ref=BrianNoobDev) [🏡 Visit my farm](https://sunflower-land.com/play/#/visit/8086340688343031) [🎥 My Youtube](https://youtube.com/@briannoobdev)*

<br>


## 👋 About Me

---

I'm a developer who love farming game.Luckily, I found Sunflower Land, a game that help me enjoy in my free time. Thanks SFL's team for created a nice game.
Also, I love to share my knowledge not only about playing SFL but also about my experiences as a developer so I create a Youtube channel. Now, I only make video about SFL and use my native language (Vietnamese) but I plan to use English for international audience in the future.
Thanks for visit my personal page!!!

##  🏡 My Farm Story
I start my new account from 03 Oct 2025. Nowadays, resources are so cheap, I upgrade my land to desert and my bumpkin to level 81 in just 11 days. I plan to go to volcano as soon as possible and prepare for the next season.
![img_20251014_001940.jpg](/user-pages/img_20251014_001940.jpg)
<br>
I will update my progress here!!! Come one volcano 🌋🌋🌋.