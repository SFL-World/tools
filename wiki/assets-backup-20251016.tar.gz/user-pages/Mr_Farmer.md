---
title: Mr Farmer 
description: I am a simple player like you but a little bit more lazy , a boy with an age of 20 😁 here's my farm #89508
published: true
date: 2025-10-13T15:36:13.185Z
tags: moderator
editor: markdown
dateCreated: 2025-10-13T15:34:33.190Z
---

**Mr_ Farmer**

visit my farm https://sunflower-land.com/play/#/visit/89508

i am a normal player like you but a little bit more lazy 🦥 😉 a 20 year old boy with a craze for the game, i was in the game from the year 2022 but changed my farm 3 times heres my farm id #89508 visit me cheer me and get cheere back 🥂 