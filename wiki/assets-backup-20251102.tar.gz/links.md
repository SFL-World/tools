---
title: Links
description: 
published: true
date: 2025-10-21T16:58:17.243Z
tags: 
editor: markdown
dateCreated: 2025-10-20T18:07:18.600Z
---

# Links

## Official Links
- [Play Sunflower Land](https://sunflower-land.com/play/)
- [Discord](https://discord.gg/sunflowerland)
- [Github](https://github.com/sunflower-land/sunflower-land)
- [Docs](https://docs.sunflower-land.com/)

## Social Networks
- [Youtube](https://www.youtube.com/c/SunflowerLand)
- [Twitter](https://twitter.com/0xsunflowerland?lang=en)
- [Instagram](https://instagram.com/0xsunflowerland)
- [Twitch](https://www.twitch.tv/0xsunflowerstudios)
- [Telegram](https://t.me/SunflowerLandAnnouncements)

## NFT collections
- [Sunflower Land Accounts](https://opensea.io/collection/sunflower-land)
- [Sunflower Land Collectibles](https://opensea.io/collection/sunflower-land-collectibles)
- [Sunflower Land Buds](https://opensea.io/collection/sunflower-land-buds)
- [Bumpkin Wearables](https://opensea.io/collection/bumpkin-wearables)
- [Sequence Market](https://sunflowerland.sequence.market/)
- [MOOAR](https://mooar.com/collection/sunflower/collectibles)

## Telegram
- ![](https://flagcdn.com/w20/us.png) [Sunflower Land World [EN]](https://t.me/sfl_world)
- ![](https://flagcdn.com/w20/ru.png) [Sunflower Land World [RU]](https://t.me/sfl_world_ru)
- ![](https://flagcdn.com/w20/ua.png) [Sunflower Land World [UA]](https://t.me/sfl_world_ua)
- ![](https://flagcdn.com/w20/br.png) [Sunflower Land Brasil](https://t.me/SunflowerLandOficialBr/33)

## YouTube
- ![](https://flagcdn.com/w20/us.png) [Sunflower Land Official](https://www.youtube.com/@SunflowerLand)
- ![](https://flagcdn.com/w20/br.png) [Diário do Fazendeiro no Sunflower Land](https://www.youtube.com/@DiariodoFazendeiro)
- ![](https://flagcdn.com/w20/us.png) [It's me DH](https://www.youtube.com/@itsme_dh)
- ![](https://flagcdn.com/w20/us.png) [Xeko Gaming](https://www.youtube.com/@xeko)
- ![](https://flagcdn.com/w20/us.png) [Rokirok journey](https://www.youtube.com/@Rokirokjourney)
- ![](https://flagcdn.com/w20/ru.png) [Usual routine Goblin](https://www.youtube.com/@usual.routine.goblin)

## Community Links
- [Boost NFT List by iK, Micsk & French Chat](https://docs.google.com/spreadsheets/d/1n4PE0ZE3rYztCsSwh6pu0uaNcoZroBnOOuv2FlLik7c/edit?gid=0#gid=0)
- [Skill Points Calculator By iK, Elowine, LaMouette, DDoubled & Fabuu](https://docs.google.com/spreadsheets/d/1N2LeM-Ik96R3hMSY_j4TvXWWA8GJ4EtZoguLoHmxqtc/edit?gid=0#gid=0)
- [Combo Maker](https://docs.google.com/spreadsheets/d/1IR8_gib9KpY2V0aDNa4TX9oc4rIzKnKBGnj2ybZFlOo/edit?gid=1807520899#gid=1807520899)
- [Crops to Coins](https://docs.google.com/spreadsheets/d/1QIiViEHYxPqKAUs-fmYlBDo99ZmecpLT_oMVDRiToLA/edit?gid=982574094#gid=982574094)