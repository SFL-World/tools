---
title: Bud NFTs
description: 
published: true
date: 2025-10-31T08:00:28.712Z
tags: game-mechanics, nft, bud
editor: markdown
dateCreated: 2025-10-31T02:32:33.347Z
---

# Bud NFTs
Buds are special companions in Sunflower Land that provide global passive buffs to various in-game systems such as crops, animals, resources, and production. Each Bud belongs to a specific Type, may feature a unique Stem, and can possess an Aura that amplifies its effects.

Only 2,621 of the originally planned 5,000 Buds were minted, making them limited-supply collectibles. All Bud effects apply globally (not area-based) and remain active as long as the Bud is owned and placed in the land.

# Lore

Buds are magical beings born from ancient Bud Seedlings, cultivated and harvested by Bumpkins. They’ve been loyal farming companions since the earliest days of Sunflower Land, embodying the deep bond between nature, magic, and the Bumpkin way of life.

Legends describe Buds as keepers of agricultural wisdom, guiding generations of farmers toward prosperity. Their appearance and abilities evolved according to where they were planted, giving rise to ten distinct Types, each reflecting its native environment and subsequent buff. 

Over time, experimentation and natural cross-breeding between Buds of different Types led to unexpected mutations. Some Buds began to develop Stems, external growths resembling hats that mirrored either their own Type or traits from other Types. These Stems became sources of visual variation and, in some cases, powerful secondary buffs, marking the first documented evolutionary divergence among Buds.

A long time ago, the mischievous Goblins discovered half of the Bud Seedlings and grew their own versions. These Goblin Buds share the same powers as their Bumpkin counterparts but bear the distinctive Goblin Ears, symbolizing their origin. When Buds were revealed, there was a 50/50 chance it would be a Goblin Bud or a Bumpkin Bud.

When Bumpkins and Goblins first competed over Bud Seedlings, residual magical from both sides infused the sprouts with unstable magical energy. The result: Auras, visible manifestations of that lingering hybrid magic, growing stronger and rarer depending on the balance of Bumpkin and Goblin influence in the soil.

# Types
Each Bud Type determines its picture background environment and grants a fixed buff that affects a specific resource or product.

Plaza	+0.3 Basic Crops
Castle	+0.3 Medium Crops
Snow	+0.3 Advanced Crops
Saphiro	−10% Crop Growth Time
Beach	+0.2 Fruit
Woodlands	+0.2 Wood
Cave	+0.2 Minerals
Retreat	+0.2 Animal Produce
Sea	10% chance of +1 Fish
Port	+10% Fishing XP

# Stems

#### Buffed Stems
Several stems grant fixed buffs. If the Stem and Type share the same category (e.g., both affect crops or minerals), their effects stack on the same Bud. Otherwise, only the strongest effect per category applies globally.

**Stem	Buffs**
Basic Leaf	+0.2 Basic Crops
Sunflower Hat	+0.5 Sunflower
Carrot Head	+0.3 Carrot
Three-Leaf Clover	+0.5 Crops (has priority over all crop-type stem buffs; stacks only if it's on a bud with a crop buff Type)
Apple Head	+0.2 Fruit
Banana	+0.2 Fruit
Acorn Hat	+0.1 Wood
Tree Hat	+0.2 Wood

Ruby Gem	+0.2 Stone
Miner Hat	+0.2 Iron
Gold Gem	+0.2 Gold
Diamond Gem	+0.2 Minerals (has priority over all mineral-type stem buffs, stacks only on Cave type Bud)
Egg Head	+0.2 Egg
Fish Hat 10% chance of +1 Fish
Mushroom	+0.3 Mushroom
Magic Mushroom	+0.2 Magic Mushroom

**Cosmetic Stems**
No buffs, purely visual. They do not modify bonuses.
Axe Head
Hibiscus
Rainbow Horn
Red Bow
Seashell
Silver Horn
Sunflower Headband
Sunshine Foliage
Tender Coral

# Auras and Rarity
While Buds do not have official rarity tiers, their Aura determines their rarity and power. Some Buds have no aura, offering only their base Type buff. Aura multipliers apply independently and simultaneously to both the Type and Stem buffs on the same Bud.

No Aura	= Base type buff only
Basic Aura (White) 5%	boost
Green	Aura (Green) 20%	boost
Rare	Aura (Yellow)	100%	boost
Mythical Aura (Light Blue) 400%	boost

# Buff Mechanics and Stacking Rules
Every Bud provides its Type buff, even with no Aura.
Aura multipliers amplify both Type and Stem buffs independently and simultaneously.
Buffs of the same category (Crops, Minerals, Fruit, etc.) do not stack across different Buds; only the strongest total (base + aura) is applied, however, if a Bud’s Stem buff matches its Type buff, the bonuses stack on that single Bud.
The Three-Leaf Clover Stem takes priority over all other crop buffs but can stack with its Type buff if it's a crop category.
The Diamond Gem Stem takes priority over all mineral buff stems, and can stack with the Cave Type when both are on the same Bud.

# Visual Traits
All Buds share a fixed body design but has variations which include:
Color Palettes: Silver, Gold, Green, Blue, Red, Purple, Stone, Brown, Beige, Orange, Diamond, Rainbow
Ears: Can appear with or without
Stems: Cosmetic or buff-based as listed previously
Auras: Visible glow indicating rarity and power level
Each Bud’s Type determines the environment in its image background (e.g., Sea Buds have oceanic scenery, Cave Buds have rocky caverns).

# Strategic Notes
Buds with matching Type and Stem buffs are the most efficient.
Aura rarity often determines economic and strategic value; Mythical Aura Buds vastly outperform lower tiers.
Clover and Diamond Gem stems act as override archetypes, ensuring only one of each resource or crop category is dominant per land.
Players often optimize Bud collections by maintaining unique Type coverage to maximize buff variety instead of duplicates.

All values, categories, and stacking rules verified as of 2025-10.