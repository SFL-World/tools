---
title: Farm Pets
description: 
published: true
date: 2025-10-30T22:56:45.058Z
tags: game-mechanics, unreleased
editor: markdown
dateCreated: 2025-10-23T19:47:55.920Z
---

***This is an unreleased game feature. The final version of this mechanic may be different from what is described here. More details will be added when they are confirmed.***

*Not to be confused with the* [*Faction Pet*](https://wiki.sfl.world/en/factions/pet)

# Farm Pets

Add a furry (or feathery, or scaly) companion to your farm and enjoy the many benefits of your new friend. Pets are a collectible and progression system designed to create hype, excitement, and a burn mechanic for FLOWER and Chapter progression. They feature an iterative proposal with proof of concept designs.

![444250847-a5516bdc-691a-4589-bfee-5a7474ca1614.gif](/game-mechanics/pets/444250847-a5516bdc-691a-4589-bfee-5a7474ca1614.gif)

Every Pet hatches out of an egg, even those that normally don't in real life! There are several ways for you to get your first egg:

-   Purchase one at the Pet Shop in the Plaza for 150,000 Coins (once ever)
-   Purchase one at the Love Shop on the Floating Island for 10,000 Love Charms (once ever)
-   Purchase one at the Megastore for 1,500 Chapter Tickets (once per chapter)

## Pet Types

You can only get one egg from the Pet Shop and Love Shop each, so that will give you two Pets if you can get them both. There are 20 different Pet types, and you will always get a new one every Egg that you buy. So you can't get duplicates! Common pets cannot be traded.

Each Pet has a Category, which determines what kind of items they can fetch for you. There are 20 different Common Pets across 7 categories:

![480440174-8e5f24e6-6b0f-451c-8a8e-b85c0d73dbd9.png](/game-mechanics/pets/480440174-8e5f24e6-6b0f-451c-8a8e-b85c0d73dbd9.png)

-   Guardians fetch Chewed Bones
-   Hunters fetch Ribbons
-   Voyagers fetch Ruffroot
-   Beasts fetch Wild Grass
-   Moonkin fetch Heart Leaf
-   Snowkins fetch Frost Pebble
-   Foragers fetch Dewberry

Every pet has 2 or 3 Categories, so they will be able to get you multiple items. It takes approximately 4.5 years to collect all 20 common pets.

## Requests

Every day at game reset, your pet will request different foods, just like the Faction Pet. When you feed it to them, they will earn Energy and XP. Requests start with 2 per day and increase with pet level. New requests are generated every UTC changeover (similar to deliveries). Requests will remain if you don't complete them, to allow time to cook the food if needed. At the end of the day, any completed requests will be replaced with new ones. You can also reset all the requests with new ones by paying Gems (generates 3 new ones; cost increases with use).

![2025-10-31_02-48-31.png](/game-mechanics/pets/2025-10-31_02-48-31.png)

If you can't feed your pet for 3 consecutive days, it will lose 500 XP. This will only happen once, though, so if you need to take an extended leave from the game you will only incur the penalty one time, not every 3 days during your absence.

Your pets will sleep periodically, and can be tapped on to gain a small amount of XP (+10 XP every 2 hours during 'nap' mode). In addition, visitors to your farm can pet your creature to give it some bonus XP (+1 to +5 XP, capped at 50 XP per pet per day from social help).

Pet food uses existing Bumpkin food, with suggestions for crop/animal-based preferences (e.g., dog prefers anchovy) and special meals via new buildings or shops.

## Fetching

Once your pet has some Energy, you can send it out on quests to find items for you. The Acorn is a standard item that every pet can find, and has multiple different uses (used in deliveries, chums, or sold for coins; non-tradeable). The other items it can find are dependent on its Category, and its Level. Sending it to fetch consumes the displayed amount of energy. Pets fetch resources based on type and level.

![2025-10-31_02-50-21.png](/game-mechanics/pets/2025-10-31_02-50-21.png)

Suggestions include quests/missions based on level, Bumpkin level, time, and resource cost, with potential co-op elements and reward boosts.

## Experience

Leveling up your pet will grant it different perks, such as more items available to fetch, more foods available for requests, and other bonuses. There is currently no level cap for a pet, so feed it and watch it grow! XP progression is quadratic (e.g., Level 2: 120 XP, Level 3: 300 XP, Level 4: 600 XP).

| Level | Perk |
|-------|------|
| 3 | Unlock Category (fetch non-acorn resource) |
| 5 | +5 energy per pet food |
| 7 | Unlock 2nd Category |
| 10 | 3 Requests per day |
| 12 | Unlock Moonfur (**NFT ONLY**) |
| 15 | 10% chance of double resource |
| 18 | +1 Acorn yield |
| 20 | Unlock Fossil Shell |
| 25 | Unlock 3rd Category (**NFT ONLY**) |
| 27 | Pet Experience +10% |
| 30 | 4th request per day (**NFT ONLY**) |
| 35 | +5 energy per pet food (+10 total) |
| 40 | Pet Experience +15% (25% total **NFT ONLY**) |
| 50 | 15% chance of double resource |
| 60 | +1 non-acorn/moonfur resource yield (**NFT ONLY**) |
| 75 | +5 energy per pet food (+15 total) |
| 85 | Pet Experience +25% (50% Total **NFT ONLY**) |
| 100 | 25% chance of double resource |
| 150 | 50% chance +1 Moonfur yield (**NFT ONLY**) |
| 200 | 5th food request (**NFT ONLY**) |

There is no sickness mechanic for pets.

## Shrines

Shrines are special buildings that are placed on your farm, and take Pet resources to craft. Resources other than Acorns are tradeable, so you can get them from farmers who have different pet categories. Shrines are crafted in the plaza using the Pet/Shrine Shop and are limited by Acorn input (depends on number of pets fetching Acorns). They are used to produce shrines with pet resources. Suggestions include more accessibility, like a Planter Shrine for end-game automation.

## NFT Pets

Special collectible and tradeable Pets will also be available to those resourceful players who can obtain them. These NFT Pets function just like the commonly-available ones, eating food and taking requests and so on, but have special properties that boost their XP and Energy gains. Their XP and levels will persist even if they are traded to another player, so their value will only grow as you raise them!

- **Total Supply**: 3000 NFT Eggs.
- **Initial Drop**: 1000 Eggs in FLOWER Auction (November 3rd-10th), 50 per auction; players can win multiple (up to 20).
- **Remaining**: Available each Chapter with tickets (250 total, including Pet Chapter).

**Attributes**:
- 450 unique per pet type (Dragon: 300).
- 15 fur/colour patterns, 10 accessories (wings, horns), 3 bibs.
- Auras: Mega (3x Energy, 60 pets), Epic (2x, 120), Basic (1.5x, 240).
  - Per Chapter: 5 Mega, 10 Epic, 20 Basic.
  - Initial Drop: 20 Mega, 40 Epic, 80 Basic.

NFT Pets can also find a unique resource called Moonfur, which is highly sought-after.

Finally, these Pets will follow their owners around when they visit the Plaza, and other players will be able to pet them as they pass by. Auras multiply energy gains, and bibs provide XP bonuses on feeds: Basic (none), Mid (+5 XP), Great (+10 XP).

**Limitations**:
- Players can manage only 1 pet per type (max 7 NFT pets).
- Experience retained on in-game trades; lost on withdrawal.
- Common pets are tradeable but reset to Level 20 on transfer.
- No in-game naming; suggestions for nicknames.

## Updates & Notes

- **Ready Proposal**: Marked as Ready on August 21st, 2025.
- **Revisions**: Significant revision on August 1, 2025; clarified mechanics and removed some ambiguities.

> Contributors to this page
> 
> [librophagus](https://wiki.sfl.world/en/user-pages/librophagus) - primary content
> [Andrei](https://wiki.sfl.world/en/user-pages/Andrei) - additional edits
> 
> Additional details from GitHub Discussion #5657 contributors:
> 
> - [@adamhannigan](https://github.com/adamhannigan): Confirmed no max level, no sickness, reused Bumpkin food, clarified NFT vs Common pet differences, and addressed trading mechanics.
> - [@eliasSFL](https://github.com/eliasSFL): Clarified Level 200 perk as 5th food request (typo fix).
> - Community suggestions for quests, food variety, and balanced distribution to avoid whale dominance.