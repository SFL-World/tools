---
title: About Sunflower Land
description: 
published: true
date: 2025-10-10T16:11:15.813Z
tags: 
editor: markdown
dateCreated: 2025-10-06T09:20:48.617Z
---

# About Sunflower Land

Sunflower Land is a **community-driven Web3 farming game** where every action matters. Plant crops, raise animals, complete quests, and trade with thousands of other players across the world.

With over **600,000+ farms created**, a thriving NFT marketplace, and non-stop seasonal updates, Sunflower Land is not just a game — it’s a living, breathing world shaped by its players.

![](/about sunflowerland/animation.gif)

*_The information provided on this website does not constitute investment advice, financial advice, trading advice, or any other sort of advice and you should not treat any of the website’s content as such. We do not recommend that any cryptocurrency should be bought, sold, or held by you. Use the information from these pages at your own risk._*

# **🔑Crypto & Digital Collectibles**

Sunflower Land is powered by Web3. That means your **tokens, SFTs (stackable collectibles), and NFTs (unique items)** can live on-chain and be freely owned/traded by you.

Sunflower Land Digital Collectibles are traded **in-game** and also supported on all major secondary NFT marketplaces.

👉 **Important:** You only need to set up a wallet once you’re ready to trade, deposit, or withdraw assets. Most of the game can be played without touching Web3 at first.

### **FLOWER ERC20**

FLOWER is the native ERC20 token used for trading & premium actions in game. (see $FLOWER ERC20)

[Uniswap - Buy now](https://app.uniswap.org/swap?chain=base&inputCurrency=0x3e12b9d6a4d12cd9b4a6d613872d0eb32f68b380&outputCurrency=0x833589fCD6eDb6E08f4c7C32D4f71b54bdA02913&value=1&field=input) 

![](/about sunflowerland/flowererc.png)

###   
**Farm Collectibles**

Supply limited cosmetics & items to boost your farm.

[https://opensea.io/collection/sunflower-land-collectibles](https://opensea.io/collection/sunflower-land-collectibles)

![](/about sunflowerland/collectibles.png)

### **Bumpkin Wearables**

Fashionable cosmetic & powerful outfits for your Bumpkin.  
[https://opensea.io/collection/bumpkin-wearables](https://opensea.io/collection/bumpkin-wearables)

![](/about sunflowerland/wearables.png)

### **Bud NFTs**

Sprouted from the ground, these unique collectibles can give buffs for your farm.

[https://opensea.io/collection/sunflower-land-buds](https://opensea.io/collection/sunflower-land-buds)

![](/about sunflowerland/buds.png)

### Pet NFTs

coming soon

> **Contributors to this page** 
> 
> [iSPANK](/en/user-pages/iSPANK) \- initial creation / copying from official Docs